> ## Python Version
> 3.8+

---

> ## Requirements
> - Appium-Python-Client
> - requests

---

> **To Install Requirements**
>
> `pip3 install -r requirements.txt`

---

> **To Run Test Script**
>
> `python3 ./test_myVerzion_ios.py`
>
> *OR*
>
> `python test_myVerzion_ios.py`
